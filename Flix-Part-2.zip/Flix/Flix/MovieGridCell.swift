//
//  MovieGridCell.swift
//  Flix
//
//  Created by user191262 on 2/4/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
